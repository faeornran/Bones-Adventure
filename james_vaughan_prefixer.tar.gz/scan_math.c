/* James Vaughan - scan_math.c
 *
 * This file contains the necessary code to scan a text file
 * and return the results in a standard form for the parser.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "scan_math.h"

// Returns a new empty scan_node.  Exits if out of memory.
scan_node new_scan_node()
{
  scan_node s = (scan_node) malloc (sizeof(*s));
  if ( !s ) exit_prefixer("Not enough memory for new scan node.", NULL);
  return s;
}

void free_scan_node(scan_node node)
{
  node->next = NULL;
  if ( node->data ) {
    free(node->data);
  }
  free(node);
}

// Scans the next token, returning the corresponding scan_node.
// Returns multiple linked scan_nodes if the token contains more than
// one type of object.  This has some redundant code; I could
// create a function that accepts function pointers in order to reduce the amount
// of code but due to time constraints I am leaving this as is.
// See further comments for more details.
scan_node scan_token(char *token)
{
  scan_node s = new_scan_node();

  // First, test if token starts as a number.
  if ( token[0] >= '0' && token[0] <= '9' ) {
    int i;
    bool_t non_alphanum_found = FALSE;
    bool_t char_found = FALSE;
    // Keep interating until non-number found, or \0 is found
    for ( i = 1; token[i] != '\0'; i++ ) {
      // Finds the start of an algebraic multiply
      if ( (token[i] >= 'a' && token[i] <= 'z') || (token[i] >= 'A' && token[i] <= 'Z') ) {
        char_found = TRUE;
        break;
      // Finds the start of a potential new non-alphanumeric token
      } else if ( token[i] < '0' || token[i] > '9' ) {
        non_alphanum_found = TRUE;
        break;
      }
    }
    // Sets the node's details to what we found, initializing the data.
    s->oper = "INT";
    s->data = (char*) calloc(i+1, sizeof(char));
    strncpy(s->data, token, i);

    // Recursively generates two more nodes if alphabetic character found.
    // Example: "456asdf" is treated as "456 * asdf"
    if ( char_found ) {
      s->next = scan_token("*");
      s->next->next = scan_token(token + i);
    // Recursively generate next symbol if token contains more data.
    } else if ( non_alphanum_found ) {
      s->next = scan_token(token + i);
    }
    return s;
  }
  
  // Checks for algebraic variable name.
  if ( (token[0] >= 'a' && token[0] <= 'z') || (token[0] >= 'A' && token[0] <= 'Z') ) {
    int i;
    bool_t non_id_found = FALSE;
    for ( i = 1; token[i] != '\0'; i++ ) {
      char c = token[i];
      // Checks if a non-alphanumeric character is found.
      if ( c < '0' || (c > '9' && c < 'A') || (c > 'Z' && c < 'a') || c > 'z' ) {
        non_id_found = TRUE;
        break;
      }
    }

    // Initialize new node and set data.
    s->oper = "ID";
    s->data = (char*) calloc(i+1, sizeof(char));
    strncpy( s->data, token, i );

    // Recursively generate next symbol if token contains more data.
    if ( non_id_found ) s->next = scan_token(token + i);
    return s;
  }

  // Otherwise, check for operator tokens.  This does not
  // include the exponential as I do not have enough time to code it.
  switch ( token[0] ) {
    case '+': s->oper = "+"; break;
    case '-': s->oper = "-"; break;
    case '*': s->oper = "*"; break;
    case '/': s->oper = "/"; break;
    case '(': s->oper = "("; break;
    case ')': s->oper = ")"; break;
    default:
      exit_prefixer("scan_token: Character not recognized in token.  Remainder: ", token);
  }
  // Continue scanning if there is more data after the first character.
  if ( token[1] ) s->next = scan_token(token + 1);
  return s;
}

// This function scans a file, tokenizes it and passes the tokens into scan_token
// continuously, building the tree as it goes through the file.
scan_node scan_file(FILE *file)
{
  char *delims = " \t\n\r";
  char line[PREFIXER_CHARS_PER_LINE];
  // Keep track of a dummy head.
  scan_node front = new_scan_node();
  front->oper = "$";

  scan_node temp_node = front;

  // While there is still input in the file, keep reading PREFIXER_CHARS_PER_LINE
  // characters, or store less if the line ends in less than 100 characters.
  while ( fgets(line, PREFIXER_CHARS_PER_LINE, file) ) {
    // Begin tokening the string that was read.
    char *token = strtok(line, delims);

    // Guaranteed at least one token, so read it.
    do {
      // Generate next set of tokens
      temp_node->next = scan_token(token);
      if ( !temp_node->next ) exit_prefixer("scan_token returned NULL scan_node.", NULL);
      // Iterate until at the end of the token list to find the next placement
      while ( temp_node->next ) temp_node = temp_node->next;
    } while ( (token = strtok(NULL, delims)) ); // Loop while there's still tokens to read.
  }

  return front;
}
