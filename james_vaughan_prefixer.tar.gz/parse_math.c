#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "parse_math.h"

// Parses a list and returns another list in prefix order.
scan_node parse_scanned_list(scan_node head)
{
  if ( !head ) exit_prefixer("parse_scanned_list: Invalid list head provided.", NULL);

  // Dummy head; grab the next symbol.
  // Set up return list with dummy head for easy paren placement
  scan_node return_list = new_scan_node();
  return_list->oper = "$";
  
  scan_node left = NULL;
  scan_node oper = NULL;
  scan_node right = NULL;
  
  while ( head->next ) {
    if ( !strcmp(head->next->oper, ")" ) ) {
      exit_prefixer("parse_scanned_list: Closed paren without opening.", NULL);
    } else if ( !strcmp(head->next->oper, "(" ) ) {
      // Check for precedence.
      head->next = head->next->next;
      // Parse inside the parentheses - expect a right paren to remain.
      left = parse_scanned_list(head);
      
      if ( !head->next ) return left; // Ensures we don't consume too many end parentheses and segfault.
      if ( strcmp(head->next->oper, ")") ) {
        // Missing right paren.
        exit_prefixer("parse_scanned_list: Opened paren without closing.", NULL);
      }
      head->next = head->next->next;
      if ( !head->next ) return left;
    } else if ( !strcmp(head->next->oper, "INT") || !strcmp(head->next->oper, "ID") )  {
      // If INT or ID
      if ( head->next->next == NULL || !strcmp(head->next->next->oper, ")") ) {
        // If this is the last node or a paren is coming up, consume the token and return
        scan_node temp = head->next;
        head->next = head->next->next;
 
        // Make sure we can advance the token before doing so.
        if ( head->next && head->next->next ) head->next = head->next->next;
        temp->next = NULL;
        return temp;
      } else {
        // Otherwise, start parsing moar.
        left = head->next;
        head->next = head->next->next;
        left->next = NULL;
      }
    } else if ( strcmp(head->next->oper, "INT") && strcmp(head->next->oper, "ID") ) { 
      // Got one of the typical math operators.
      if ( !return_list->next ) {
        exit_prefixer("parse_scanned_list: Was not expecting an operator.\n", NULL);
      }

      // Subtree of at least one operator and two ints/ids, so set the child.
      left = return_list->next;
    } else {
      exit_prefixer("parse_scanned_list: Unexpected token- ", head->next->oper);
    }
  
    // Just read the left part of in-fix; next read operator
    oper = head->next;

    head->next = head->next->next;
  
    if ( !strcmp(oper->oper, "*") || !strcmp(oper->oper, "/") ) {
      // Check for higher precedence operators
      if ( !strcmp(head->next->oper, "(") ) {
      // If open paren after operator, start a new parse stack on it.
        right = parse_scanned_list(head);
      } else if ( !strcmp(head->next->oper, "INT") || !strcmp(head->next->oper, "ID") ) {
        // Otherwise, check for data and set it it.
        right = head->next;
        head->next = head->next->next;
        right->next = NULL;
      } else {
        exit_prefixer("parse_scanned_list: Expected INT or ID, got ", head->next->oper);
      }
    } else if ( !strcmp(oper->oper, "+") || !strcmp(oper->oper, "-") ) {
      // Check for lower precedence operators; continue reading tokens.
      right = parse_scanned_list(head);
    } else {
      exit_prefixer("parse_scanned_list: Unexpected token- ", oper->oper);
    }
  
    // Set up the tree properly in the list.
    oper->next = left;
    scan_node temp = left;
    while ( temp->next ) temp = temp->next;
    temp->next = right;
    return_list->next = oper;
    if ( head->next && !strcmp(head->next->oper, ")") ) {
      head->next = head->next->next;
      break;
    }
  }
  return return_list;

}

// Reduces a parsed list and returns the reduced list without its dummy head.
scan_node reduce_parsed_list(scan_node head)
{
  while ( head->next ) {
    // Grab first node & advance head
    scan_node oper = head->next;
    head->next = head->next->next;
    if ( !strcmp(oper->oper, "$") ) {
      // Ignore $ nodes 
      continue;
    } else if ( !strcmp(oper->oper, "INT") || !strcmp(oper->oper, "ID") ) {
      // Return singleton results
      return oper;
    }
    // Recursively examine the left and right parts of the operator
    scan_node left = reduce_parsed_list(head);
    scan_node right = reduce_parsed_list(head);


    if ( !strcmp(left->oper, "INT") && !strcmp(right->oper, "INT") ) {
      // Both sides are integers: reduce!
      if ( !strcmp(oper->oper, "/") && !strcmp(right->data, "0") ) {
        // Right side was a zero, so we explode the world and move on.
        printf("Kaboom!  Division by zero.\n");
      } else if ( strcmp(oper->oper, "/") ) {
        // Otherwise, we perform the operator as long as it isn't division.
        int lval = atoi(left->data);
        int rval = atoi(right->data);
        char *value = (char*) calloc(MAX_INT_SIZE, sizeof(char));
        if ( !strcmp(oper->oper, "+" ) ) {
          // Addition!
          sprintf(value, "%d", lval+rval);
        } else if ( !strcmp(oper->oper, "-") ) {
          // Subtraction!
          sprintf(value, "%d", lval-rval);
        } else {
          // That other thing!  (multiplication)
          sprintf(value, "%d", lval*rval);
        }

        // Replaces oper's data and eliminates the side nodes, shortening the list.
        free(oper->data);
        oper->oper = "INT";
        oper->data = value;
        oper->next = right->next;
        free_scan_node(left);
        free_scan_node(right);
      }
    } else if ( !strcmp(left->oper, "ID") && !strcmp(right->oper, "ID") && 
                !strcmp(left->data, right->data) ) 
    { // Both are IDs and their names are the same.
      if ( !strcmp(oper->oper, "+") ) {
        // Instead of printing out the same name twice, print a (* 2 <name>)!
        left->oper = "INT";
        strncpy(left->data, "2", 1); // guaranteed to have at least size 2 data string
        oper->oper = "*";
      } else if ( strcmp(oper->oper, "*") ) {
        // Disregard multiplication, acquire mathematical reduction.
        oper->next = right->next;

        // We know that x / x = 1 and x - x = 0, so we free both children.
        free_scan_node(left);
        free_scan_node(right);

        // Operator becomes an integer.
        oper->data = (char*) calloc(2, sizeof(char));
        char *node_val = "0"; // If subtracting
        if ( !strcmp(oper->oper, "/") ) node_val = "1"; // If dividing
        oper->oper = "INT";
        strncpy(oper->data, node_val, 1);
      } 
    }
    return oper;
  }
  exit_prefixer("reduce_parsed_list: Somehow reached the end of the list in some mystical, \
unfortunate circumstance.  (The parsing function sucks, maybe?)\n", NULL);
  return NULL;
}

// Extracts the data from the next node.
// I was going to clean this up a bit but I am pressed for time.
void extract_info(scan_node head, char **data)
{
  if ( !head->next ) { 
    *data = "";
  } else {
    if ( strcmp(head->next->oper, "INT") && strcmp(head->next->oper, "ID") ) {
      // If another operator, recurse.
      *data = convert_parsed_list(head);
    } else {
      // Otherwise, store value.
      *data = head->next->data;
    }
  }
  
}

// Converts a prefixed list into its string equivalent.
char *convert_parsed_list(scan_node head)
{
  while ( head->next ) {
    if ( strcmp(head->next->oper, "$") ) {
      // Ignore $
      if ( !strcmp(head->next->oper, "INT") || !strcmp(head->next->oper, "ID") ) {
        return head->next->data;
      } else {
        // Otherwise, operator!
        char *oper = head->next->oper;
        head->next = head->next->next;

        char *left;
        char *right;

        // Get left data/type
        extract_info(head, &left);

        if ( head->next ) head->next = head->next->next;

        // Get right data/type
        extract_info(head, &right);

        int size = 5+strlen(oper)+strlen(left)+strlen(right);
        char *result = (char*) malloc(size * sizeof(char));
        
        sprintf(result, "(%s %s %s)", oper, left, right);

        return result;

      }
      
    }
    if ( head->next ) head->next = head->next->next;
  }
  return ""; // Nothing was parsed if we don't return inside the loop.
}
