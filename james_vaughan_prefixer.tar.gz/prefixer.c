#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "scan_math.h"
#include "parse_math.h"

// Runs the prefixer, using the appropriate methods to change
// in-fix math operators into pre-fixed math operators.
int main(int argc, char *argv[])
{
  char *error = "Usage: prefixer [-r] filename";
  if (argc < 2) {
    exit_prefixer(error, NULL);
  } 

  // Set up file/reduce arguments
  FILE *f = NULL;
  bool_t reduce = FALSE;
  // Does not reduce if only 2 arguments; expects a -r within the first two 
  // arguments otherwise and assumes the other is a file.  If not, exit.
  if ( argc == 2 ) {
    f = fopen(argv[1], "r");
  } else { 
    if ( !strcmp(argv[1], "-r" ) ) {
      reduce = TRUE;
      f = fopen(argv[2], "r");
    } else if ( !strcmp(argv[2], "-r" ) ) {
      reduce = TRUE;
      f = fopen(argv[1], "r");
    } else {
      exit_prefixer(error, NULL);
    }
  }

  // File open failure
  if ( !f ) {
    exit_prefixer("Error opening file.", NULL);
  }

  // Scan and get tokens
  scan_node p = scan_file(f);

  // Parse the list into an intermediate format
  scan_node list = parse_scanned_list(p);
  
  if ( reduce ) {
    // Reduce expressions
    list->next = reduce_parsed_list(list);
  }

  // Print the resulting pre-fixed expression
  printf("%s\n", convert_parsed_list(list));
  return 0;
}
