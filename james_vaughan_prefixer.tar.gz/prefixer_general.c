#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "prefixer_general.h"

// Exits the program due to an error.
void exit_prefixer(char *msg, char *token)
{
  char error[ERROR_LENGTH];
  strcpy(error, msg);
  if ( token ) {
    strncat(error, token, ERROR_LENGTH - strlen(error) - 1);
  }

  fprintf(stderr, "%s\n", error);
  exit(1);
} 
