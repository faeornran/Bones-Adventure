#ifndef PREFIXER_GENERAL_H
#define PREFIXER_GENERAL_H

#ifndef FALSE
#define FALSE 0
#define TRUE !(FALSE)
#endif

#define PREFIXER_CHARS_PER_LINE 100
#define ERROR_LENGTH 100

typedef int bool_t;

extern void exit_prefixer(char *msg, char *token);

#endif
