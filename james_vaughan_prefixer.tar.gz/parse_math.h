#ifndef PARSE_MATH_H
#define PARSE_MATH_H

#include "scan_math.h"

#define MAX_INT_SIZE 12

extern scan_node parse_scanned_list(scan_node head);
extern scan_node reduce_parsed_list(scan_node head);
extern void extract_info(scan_node head, char **data);
extern char *convert_parsed_list(scan_node head);


#endif
