#ifndef SCAN_MATH_H
#define SCAN_MATH_H

#include "prefixer_general.h"

struct scan_node_struct;
typedef struct scan_node_struct *scan_node;

struct scan_node_struct
{
  char *oper;
  char *data;
  scan_node next;
};

extern scan_node new_scan_node();
extern void free_scan_node(scan_node node);
extern int set_data(scan_node node, char *oper, char *data);
extern scan_node scan_token(char *token);
extern scan_node scan_file(FILE *file);



#endif
